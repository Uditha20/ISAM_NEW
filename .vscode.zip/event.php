<?php
require_once './include/header-page.php';
$conn=new mysqli("localhost","root","","isams");

if ($conn->connect_error){
    die($conn->connect_error);
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./css/pagec.css">

</head>

<body>
</body>

<!--header and navigation bar-->
<header id="header">
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand" href="./index.php">ISAMS</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
          <li class="nav-item">
          <a href="../logout.php" class="sign"><h5>sign out</h5> <i class="bi bi-box-arrow-right"></i></a>
          </li>
        </ul>
      </div>
  </nav>
</header>


<section id="hero">
<?php
$sql = "select * from even_create;";

$result = $conn->query($sql);


if ($result->num_rows > 0) {
   while ($row = $result->fetch_assoc()) {

?><div class="card mt-3 mx-3" style="width: 18rem; display: inline-block;">

         <div class="card-body dash">
            <h5 class="card-title"><?php echo $row['event_name']; ?></h5>
            <h5 class="card-title">Date:<?php echo $row['date']; ?></h5>
            <p class="card-text">Description:<?php echo $row['description']; ?></p>
            <p class="card-text">Allowed for:<?php echo $row['permission']." students "; ?></p>

          
   

            <a href="#" class="btn btn-primary" type = "submit">Register</a>
         </div>
      </div><?php
         }
      }


            ?>