<?php

require_once '../../connection.php';

session_start();



if(!isset($_SESSION['user']) && !isset($_SESSION['login'])){
    header("location:../../../index.php");
}






?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ISAMS</title>

    <!-- google font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville&family=Open+Sans:wght@300&family=Poppins&family=Roboto:ital,wght@0,300;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/module.css">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">


</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

    <div class="container">


        <!-- Sidebar Start -->
        <div class="sidebar pe-4 pb-3">
            <nav class="navbar bg-light navbar-light">
                <a href="../../index.php" class="navbar-brand mx-4 mb-3 mt-4">
                    <h3 class="text-primary">ISAMS</h3>
                </a>

                <div class="navbar-nav w-100">
                    <a href="#" class="nav-item nav-link active">Dashboard</a>
                    <div class="nav-item dropdown mt-4">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Batch</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="../batch/dashboard.php" class=" dropdown-item ms-4 mt-2">View batch</a>
                            <a href="../batch/batch_add.php" class="dropdown-item ms-4 mt-2">Add batch</a>
                            <a href="../batch/manage_batch.php"class="dropdown-item ms-4 mt-2">Manage batch</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown mt-4">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Student</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="../student/student_Registration.php" class="dropdown-item ms-4 mt-2">Add student</a>
                            <a href="../student/dashboard.php" class="dropdown-item ms-4 mt-2">Manage student</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown mt-4">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Event</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="../event/create_event.php" class="dropdown-item ms-4 mt-2">Add Event</a>
                            <a href="typography.html" class="dropdown-item ms-4 mt-2">Manage Event</a>
                        </div>
                    </div>

                    <div class="nav-item dropdown mt-4">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Voting System</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="../voting/voting_creat.php" class="dropdown-item ms-4 mt-2">Add Voting</a>
                           
                        </div>
                    </div>


                    <div class="mt-5">

                        <a href="../../../logout.php" class="sign">sign out <i class="bi bi-box-arrow-right"></i></a>

                    </div>
                </div>
            </nav>
        </div>
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light">
                <a href="#" class="sidebar-toggler flex-shrink-0 mt-3 mb-3">
                    <span> <i class="fa fa-bars"></i></span>
                </a>
            </nav>
            <div class="mt-3">


                <!--display here-->
                <!-- </div>
   
        <!-- Sidebar End -->