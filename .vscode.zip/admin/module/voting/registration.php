<?php
require_once '../include/headerpage.php';

if(isset($_SESSION['vid']) && isset($_SESSION['cid'])&& isset($_SESSION['user_id'])){
    $cid=$_SESSION['cid'];
    $vid=$_SESSION['vid'];
    $user_id=$_SESSION['user_id'];




   $sql="insert into candidate (student_id,user_id,voting_id) values ('$cid','$user_id','$vid');";
   if ($conn->query($sql) === TRUE) {
   ?> <div class="alert alert-success alert-dismissible fade show">
   <strong>Success!</strong> Your message has been sent successfully.
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
 </div><?php
  }

}


?>