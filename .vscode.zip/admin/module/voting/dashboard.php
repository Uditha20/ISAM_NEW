


<?php
   
   require_once '../include/headerpage.php';


$sql="select * from voting_create;";

$result=$conn->query($sql);


if($result->num_rows>0){
   while($row=$result->fetch_assoc()){

     ?>
     <div class="card mt-3 mx-3" style="width: 18rem; display: inline-block;">

     <div class="card-body dash">
       <h5 class="card-title text-center"><?php echo $row['name'];?></h5>
       <h6 class="card-text">start date:<?php echo $row['date'];?></h6>
       <h6 class="card-text">start time:<?php echo $row['time'];?></h6>
       <h6 class="card-text">batch:<?php echo $row['batch_name'];?></h6>


       <a href="view.php?id=<?=$row['id']?>" class="btn btn-primary">view</a>
     </div>
   </div>
   
   <?php
   }
}


?>

