<?php
   
   require_once '../include/headerpage.php';
   ?>
   
  <section class="vh-100 gradient-custom section" >
    <div class="container py-5 h-100">
      <div class="row justify-content-center align-items-center h-100">
        <div class="col-12 col-lg-9 col-xl-7">
          <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
            <div class="card-body p-4 p-md-5">
              <h3 class="mb-4 pb-2 pb-md-0 mb-md-5"> Event Registration Form  </h3>
              <form class="form">
  
                <div class="row">
                  <div class="col-md-12 mb-4">
  
                    <div class="form-outline">
                      <label class="form-label" for="firstName">Name</label>
                      <input type="text" id="firstName" class="form-control form-control-lg" />
                    </div>
  
                  </div>
              
                </div>
                <div class="row">
                  <div class="col-md-12 mb-4">
  
                    <div class="form-outline">
                      <label class="form-label" for="firstName">Phone Number</label>
                      <input type="text" id="firstName" class="form-control form-control-lg" />
                    </div>
  
                  </div>
              
                </div>


                <div class="row">
                  <div class="col-md-12 mb-4">
  
                    <div class="form-outline">
                      <label class="form-label" for="firstName">University </label>
                      <input type="text" id="firstName" class="form-control form-control-lg" />
                    </div>
  
                  </div>
              
                </div>



                <div class="row">
                  <div class="col-md-12 mb-4">
  
                    <div class="form-outline">
                      <label class="form-label" for="firstName">Student ID</label>
                      <input type="text" id="firstName" class="form-control form-control-lg" />
                    </div>
  
                  </div>
              
                </div>

  
                <div class="row">
                  <div class="col-md-12 mb-4">
  
                    <div class="form-outline">
                      <label class="form-label" for="firstName">Birthday</label>
                      <input type="text" id="firstName" class="form-control form-control-lg" />
                    </div>
  
                  </div>
              
                </div>

          
    
  
                <div class="row">
                  <div class="col-md-12 mb-4">
  
                    <div class="form-outline">
                      <label class="form-label" for="firstName">E Mail</label>
                      <input type="text" id="firstName" class="form-control form-control-lg" />
                    </div>
  
                  </div>
              
                </div>

  
                <div class="mt-4 pt-2">
                  <input class="btn btn-primary btn-lg" type="submit" value="Submit" />
                </div>
                
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</body>
</html>













