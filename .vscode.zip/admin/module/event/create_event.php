<?php

require_once '../include/headerpage.php';

if (isset($_POST['event']) && (isset($_POST['date'])) && (isset($_POST['des'])) && (isset($_POST['permission']))) {
  $event = $_POST['event'];
  $date = $_POST['date'];
  $des = $_POST['des'];
  $permission = $_POST['permission'];

  // echo $event."</br>";
  // echo $date;
  // echo $des;
  // echo $permission;

  $sql = "insert into even_create (event_name,date,description,permission)
      values ('$event','$date','$des','$permission');";
  
  if ($conn->query($sql) === TRUE) {
    $su = 1;
  }

}
?>


<!-- Navbar Start -->

<section class="vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row justify-content-center align-items-center h-100">
      <div class="col-12 col-lg-9 col-xl-7">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">

            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Create a Event</h3>
            <?php if (isset($su)) {
                    
                    ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <strong>Success!</strong> Your message has been sent successfully.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>
                      <?php
                          } ?>


            <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">

              <div class="row">
                <div class="col-md-12 mb-4">

                  <div class="form-outline">
                    <label class="form-label" for="event">Event Name</label>
                    <input type="text" name="event" class="form-control form-control-lg" />
                  </div>

                </div>

              </div>

              <div class="row">
                <div class="col-md-12 mb-4">

                  <div class="form-outline">
                    <label class="form-label" for="firstName">Date</label>
                    <input type="date" name="date" class="form-control form-control-lg" />
                  </div>

                </div>

              </div>
              <div class="row">
                <div class="col-md-12 mb-4">

                  <div class="form-outline">
                    <label class="form-label" for="des">Description</label>
                    <input type="text" name="des" class="form-control form-control-lg" />
                  </div>

                </div>

              </div>

              <div>
                permission
              </div>
              <div class="row mt-4">
                <div class="col-md-6 mb-4">


                  <div class="form-check mt-2">
                    <input class="form-check-input" type="radio" name="permission" value="internal" id="flexRadioDefault2">
                    internal student
                  </div>
                </div>
                <div class="col-md-6 mb-4">
                  <div class="form-check mt-2">
                    <input class="form-check-input" type="radio" name="permission" value="both" id="flexRadioDefault2">
                    both internal and external student
                  </div>
                </div>
              </div>




              <div class="mt-4 pt-2">
                <input class="btn btn-primary btn-lg" type="submit" value="Submit" />
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</body>

</html>