<?php

require_once '../include/headerpage.php';

if(isset($_GET['id'])){
    $id=$_GET['id'];
    $sql = "DELETE FROM users WHERE user_id='$id';";
    if ($conn->query($sql) === TRUE) {
      ?><div class="alert alert-success alert-dismissible fade show py-5">
      <strong>Success!</strong> Record deleted successfully.
      <button type="button" class="btn-close py-5" data-bs-dismiss="alert"></button>
    </div><?php
      } 
}


?>