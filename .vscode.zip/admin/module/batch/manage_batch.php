<?php
   
require_once '../include/headerpage.php';

$sql="select * from batch;";
$result=$conn->query($sql);


?>
<div class="container">
    <div class="row">
        <div class="col-md-offset-1 col-md-10">
            <div class="panel">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col col-sm-3 col-xs-12">
                            <h4 class="title">Registerd batch List</h4>
                        </div>
                        <div class="col-sm-9 col-xs-12 text-right">
                            <div class="btn_group">
                                <input type="text" class="form-control" placeholder="Search">

                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>

                                <th scope="col">batch_name</th>
                                <th scope="col">Create_date</th>
                                <th scope="col">Action</th>


                            </tr>
                        </thead>
                        <?php

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                        ?><tbody>
                                    <tr>

                                        <td><?php echo $row['batch_name']; ?></td>
                                        <td><?php echo $row['create_date']; ?></td>                               
                                        <td><a href='delete.php?id=<?php echo $row['id']; ?>'><i class="bi bi-trash-fill px-3 " ></i></a></td>

                                    </tr>

                                </tbody>
                        <?php

                            }
                        }


                        ?>




                    </table>
                </div>

            </div>
        </div>
    </div>
</div>
</div>
</div>


</body>
