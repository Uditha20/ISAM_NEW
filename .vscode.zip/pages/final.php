<?php
$conn = new mysqli("localhost", "root", "", "isams");

if ($conn->connect_error) {
    die($conn->connect_error);
}
session_start();



if (!isset($_SESSION['user']) && !isset($_SESSION['login'])) {
    header("location:../../../index.php");
}

echo "thank you";


if (isset($_GET['id'])) {
    $user_id = $_SESSION['user'];
    $voting_id = $_SESSION['vid'];
    $id = $_GET['id'];
    
    $sql="insert into voting_result (candidate_id,student_id,voting_id) values ('$id','$user_id','$voting_id');";

    $conn->query($sql);

}?>