<?php
$conn = new mysqli("localhost", "root", "", "isams");

if ($conn->connect_error) {
  die($conn->connect_error);
}
session_start();



if (!isset($_SESSION['user']) && !isset($_SESSION['login'])) {
  header("location:../../../index.php");
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./css/pagec.css">
  <script>
    function timeout(){
      var minute=Math.floor(timeleft/60);
      var second=timeleft%60;
      if(timeleft<=0){
        window.location.href = "../index.php";
        // clearTimeout(tm);
        // document.getElementById("ti").submit();
      }else{
        document.getElementById("time").innerHTML=minute+":"+second;
      }
      timeleft--;
      var tm=setTimeout(function (){timeout()},1000);
    }
  </script>
</head>

<body onload="timeout()">

  <!--header and navigation bar-->
  <header id="header">
    <nav class="navbar navbar-expand-lg">
      <div class="container-fluid">
        <a class="navbar-brand" href="./index.php">ISAMS</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a href="../logout.php" class="sign">
                <h5>sign out</h5> <i class="bi bi-box-arrow-right"></i>
              </a>
            </li>
          </ul>
        </div>
    </nav>
  </header>
  <h2>voting system
    <script>
      var timeleft=1*60;

    </script>


    <div id="time" style="float:right;">timeout</div>
  </h2>


  <section id="hero">
    <?php

    $x = $_SESSION['user'];

    if (isset($_GET['id'])) {

      $id = $_GET['id'];

      $_SESSION['vid'] = $id;



      $sql = "select candidate.id,users.firstname,users.lastname from users,candidate where users.id=candidate.user_id and candidate.voting_id='$id';";

      $result = $conn->query($sql);

      if ($result->num_rows > 0) {

        while ($row = $result->fetch_assoc()) {

    ?>
    
    <div id="ti"  style="width: 18rem; display:inline-block;">
          <div class="card mx-4 card testimonial-card my-5">
            <div class="card-up aqua-gradient"></div>
            <div class="avatar mx-auto white">
              <img src="user.jpg" class="card-img-top; rounded-circle img-fluid" alt="...">
            </div>
            <div class="card-body text-center">
              <h5 class="card-title"><?php echo $row['firstname'] ?>&nbsp;&nbsp;<?php echo $row['lastname']; ?></h5>
              <a href="final.php?id=<?=$row['id']?>" class="btn btn-primary">vote</a>


            </div>
          </div>

          </div>
    <?php
        }
      }
    }



    $conn->close();







    ?>